package com.aimfrrr.panel

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max

class FloatingPanelService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams

    private val neon = Color.rgb(45, 180, 255)
    private val dark = Color.rgb(8, 22, 40)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(dark)
        }
        val header = TextView(this).apply {
            text = "☰  AIM FRRR   •   DRAG TO MOVE"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(neon)
            setPadding(4, 4, 4, 12)
        }
        root.addView(header)
        addAction(root, "SENSITIVITY GUIDE") {
            Toast.makeText(this, "Start with comfortable sensitivity and adjust gradually in Training Mode.", Toast.LENGTH_LONG).show()
        }
        addAction(root, "DRAG PRACTICE") {
            Toast.makeText(this, "Practice short, controlled upward swipes in the in-game Training Mode.", Toast.LENGTH_LONG).show()
        }
        addAction(root, "PERFORMANCE TIPS") {
            Toast.makeText(this, "Close unused apps, enable your phone's game mode, and keep the device cool.", Toast.LENGTH_LONG).show()
        }
        addAction(root, "MINIMIZE / CLOSE") { stopSelf() }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 180
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(root, params)
                    true
                }
                else -> true
            }
        }
        panel = root
        windowManager.addView(root, params)
    }

    private fun addAction(parent: LinearLayout, label: String, action: () -> Unit) {
        val item = TextView(this).apply {
            text = label
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(17, 55, 82))
        }
        val gap = android.widget.Space(this).apply { minimumHeight = 7 }
        parent.addView(item)
        parent.addView(gap)
        item.setOnClickListener { action() }
    }

    override fun onDestroy() {
        panel?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
