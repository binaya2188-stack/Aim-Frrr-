package com.aimfrrr.panel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val blue = Color.rgb(35, 170, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(7, 15, 29))
        }
        val title = TextView(this).apply {
            text = "AIM FRRR"
            textSize = 32f
            setTextColor(blue)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "BLUE NEON • FLOATING GAMING ASSISTANT"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        val start = Button(this).apply { text = "ENABLE FLOATING PANEL" }
        val stop = Button(this).apply { text = "CLOSE FLOATING PANEL" }
        val note = TextView(this).apply {
            text = "Training and settings helper only. It does not aim, tap, read game memory, or modify Free Fire."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(8, 24, 8, 0)
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(start)
        layout.addView(stop)
        layout.addView(note)
        setContentView(layout)

        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName"))
                startActivity(intent)
                Toast.makeText(this, "Allow display over other apps, then return and tap Enable.", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, FloatingPanelService::class.java))
                Toast.makeText(this, "AIM FRRR panel enabled", Toast.LENGTH_SHORT).show()
            }
        }
        stop.setOnClickListener {
            stopService(Intent(this, FloatingPanelService::class.java))
            Toast.makeText(this, "Panel closed", Toast.LENGTH_SHORT).show()
        }
    }
}
