# AIM FRRR — Android floating panel starter

A simple blue-neon floating gaming-assistant panel for Android 15. It is a starter source project, not a prebuilt APK.

## What it does
- Shows a movable floating panel after the user grants Android's “Display over other apps” permission.
- Offers sensitivity guidance, drag-practice tips, and general performance tips.
- Does not interact with Free Fire controls or game memory.

## Build an APK
1. On a computer, install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose **Open**, then select the extracted `Aim_Frrr_Android_Project` folder.
4. Wait for Gradle sync. If prompted, install the Android Gradle Plugin / SDK components.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. When the build finishes, choose **locate**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to your TECNO Spark 40, install it, open AIM FRRR, tap **Enable Floating Panel**, and allow **Display over other apps** in Android settings.

## Notes
- This project requires Android Studio and a computer to compile. It does not include the Gradle wrapper.
- The floating panel is a helper overlay only. It does not provide auto-aim, auto-fire, macros, game-file modification, anti-cheat bypass, or ban-evasion features.
- For distribution, configure signing and test on your own device before sharing.
